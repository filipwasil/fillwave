var searchData=
[
  ['querry',['Querry',['../classfillwave_1_1core_1_1Querry.html',1,'fillwave::core']]]
];
