var searchData=
[
  ['border',['border',['../structfillwave_1_1core_1_1TextureInfo.html#ad5ba6f1d1e81beb5f71b915848dcb651',1,'fillwave::core::TextureInfo']]]
];
